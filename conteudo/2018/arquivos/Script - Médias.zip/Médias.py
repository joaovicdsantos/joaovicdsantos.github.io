"""
Esse programa calcula a media dos alunos e cria um documento de texto com o nome
do professor, serie, nome do aluno, notas, pontos adicionais ( media e nota ),
faltas e observações.

Autor: RaolootneXII :)
"""
# Importações(ão)
import os  # O uso dela é bastante simples limpar a tela do Windows.
import platform  # Essa biblioteca é usada em conjunto com a "os" para indentificar o sistema.

# --------------
# Declaração de Variaveis ( Só para explicar a função de cada uma )
# Variaveis de Menu:
menu1 = True  # Serve para manter o loop do 1º menu.
menu2 = True  # Serve para manter o loop do 2º menu.
menuGambi = True  # Serve para manter o loop de um menu gambiarra ( hehe ).
# Variaveis de Decisão
dc1 = ''  # Serve para a primeira decisão do 1º menu.
pted = ''  # Serve na decisão se vai querer adicionar pontos.
pted2 = ''  # Serve na decisão se o ponto vai ser na média ou na nota.
obsd = ''  # Serve na decisão se vai querer fazer alguma observação.
nfd = ''  # Serve na decisão se vai querer adicionar o número de faltas.
# Variaveis normais
numN = 'j'
nf = '0'
obs = '[nenhuma observação]'
pte = ''
notex = ''
notas = 'Notas: '
nt = float(0)
n = float(0)


# ------------------------------------------


# Funções

def isfloat(valor):  # Tenta converter o valor caso der erro não é float bem simples.
    try:  # Ela também funciona como ".isnumeric()" então nesse programa algumas vezes
        float(valor)  # utilizo ela para verificar se certo valor é float ou int
        return True
    except ValueError:
        return False


def limpartelar():
    sistema = platform.system()  # Esse comando indica o systema operacional.
    if sistema == 'Windows':  # Condição pra qual sistema ta usando o script.
        os.system('cls')  # Comando para limpar a tela no Windows.
    elif sistema == 'Linux':
        os.system('clear')  # Comando para limpar a tela no Linux.


# --------------------------------------

limpartelar()  # Começa limpando a tela já só pra ficar o script na tela.
while menu1:  # Menu basico que depende se a variavel "menu1" é True.
    dc1 = input('-------------------------------------------------------\n'  # Uma variavel para
                '|                Calculadora de médias                |\n'  # decidir o que o
                '-------------------------------------------------------\n'  # usuario que fazer.
                '| 1 - Calcular médias                                 |\n'
                '| 2 - Sair                                            |\n'
                '-------------------------------------------------------\n'
                'Informe sua escolha: ')
    if dc1 == '1':  # A partir do valor da variavel a cima vai em uma decisão.
        limpartelar()  # Limpando a tela.
        nmPr = input('-------------------------------------------------------\n'  # Variavel usada
                     '|                Calculadora de médias                |\n'  # para armazenar
                     '-------------------------------------------------------\n'  # o nome do pro-
                     'Seu nome, Professor(a): ')  # fessor.
        limpartelar()  # Limpando a tela.
        numS = input('-------------------------------------------------------\n'  # Variavel usada
                     '|                Calculadora de médias                |\n'  # para armazenar
                     '-------------------------------------------------------\n'  # a serie ou ano.
                     'Qual ano/série?(9º ano,7º série): ')
        limpartelar()  # Limpando a tela.
        nmArq = input('-------------------------------------------------------\n'  # Variavel usada
                      '|                Calculadora de médias                |\n'  # para armazenar
                      '-------------------------------------------------------\n'  # o nome do ar-
                      'Como deseja que salve o nome do arquivo?               \n'  # quivo.
                      'Obs: Se um arquivo com o mesmo nome existir será apagado: ')
        limpartelar()  # Limpando a tela.

        # Com o objetivo de o número de notas não ser 0 ou <0 fiz essa gambiarra.
        while menuGambi:  # Entra no menu normalmente.
            if not numN.isnumeric():  # Como a variavel é string por padrão vai entrar aqui
                numN = 'j'  # já que a mesma, por ser string, não é um número.
                limpartelar()  # E vai continuar entrando aqui enquanto não for um número. [ Limpando a tela ]
                numN = input('-------------------------------------------------------\n'  # Variavel usada
                             '|                Calculadora de médias                |\n'  # para armazenar
                             '-------------------------------------------------------\n'  # o número de
                             'Informe um número e que ele seja maior que 0!!\n'  # notas a ser
                             'Informe o número de notas a ser calculada: ')  # calculadas.
            elif int(numN) <= 0:  # Se a variavel for um número ele passa para essa condição
                numN = 'j'  # que verifica se o valor, convertido pra int, é menor ou
                limpartelar()  # igual a 0. [ Limpando a tela ]
                numN = input('-------------------------------------------------------\n'  # Variavel usada
                             '|                Calculadora de médias                |\n'  # para armazenar
                             '-------------------------------------------------------\n'  # o número de
                             'Informe um número e que ele seja maior que 0!!\n'  # notas a ser
                             'Informe o número de notas a ser calculada: ')  # calculadas.
            else:  # Por ultimo, se a variavel for um número e maior que 0
                menuGambi = False  # ele finalmente sai do while com um valor numerico e positivo.
        arq = open('{}.txt'.format(nmArq), 'w')  # Cria um arquivo de texto com o nome dito anteriormente
        # O parametro "w" serve para indicar que é escrita ( write ).
        arq.writelines(
            'Professor(a): {}\nSérie/Ano: {}\n\n'.format(nmPr, numS))  # Escreve o que foi passado anteriormente.
        arq.close()  # Fecha o arquivo.
        while menu2:  # Entra no menu normalmente.
            limpartelar()  # Limpando a tela.
            ltemp = list(range(2))  # Criando uma lista para armazenar o nome e a media ( poderia ser variaveis ).
            ltemp[0] = input('-------------------------------------------------------\n'  # Variavel usada
                             '|                Calculadora de médias                |\n'  # para armazenar
                             '-------------------------------------------------------\n'  # o nome do aluno.
                             '| Quando quiser sair escreva "sair"                   |\n'
                             '-------------------------------------------------------\n'
                             'Nome do aluno: ')
            if ltemp[0] == 'sair':  # Se caso o nome do aluno seja "sair" ele fecha o menu e volta para o incial.
                menu2 = False  # Dando a variavel menu2 um valor falso para sair do loop.
                limpartelar()  # Limpando a tela.
            else:  # Se caso o nome não seja "sair" ele entra nesse bloco
                limpartelar()  # Limpando a tela.

                # Essa é realmente uma gambiarra que fica dificil até de explicar ( hehe ).
                i = 1  # Variavel para manter um loop no while.
                contador = 0  # Dependendo do valor dessa variavel irá mostrar na tela uma mensagem diferente.
                while i <= int(numN):  # Entrando num loop para pedir as notas de acordo com o número de notas
                    #                    passado anteriormente.
                    if contador == 0:  # Como a variavel contador é 0 entra aqui e mostra uma mensagem sem
                        # alerta de erro.
                        nt = input('-------------------------------------------------------\n'  # Variavel usada
                                   '|                Calculadora de médias                |\n'  # para armazenar
                                   '-------------------------------------------------------\n'  # a nota.
                                   '{}º nota: '.format(i))  # Esse format serve para indicar a nota que está
                    else:  # Se a variavel não for 0 significa que o usuario ja errou uma vez então entra aqui
                        #    mostrando a mensagem com o alerta de erro.
                        nt = input('-------------------------------------------------------\n'  # Variavel usada
                                   '|                Calculadora de médias                |\n'  # para armazenar
                                   '-------------------------------------------------------\n'  # a nota.
                                   'Escreva um número que seja maior ou igual a 0 e menor  \n'
                                   'ou igual a 10, por favor!!\n'
                                   '{}º nota: '.format(i))  # Esse format serve para indicar a nota que está
                    while not isfloat(nt):  # Se o valor da variavel não for um número entra nesse while que pede o
                        limpartelar()  # valor até ele ser float. [ Limpando a tela ]
                        nt = input('-------------------------------------------------------\n'  # Variavel usada
                                   '|                Calculadora de médias                |\n'  # para armazenar
                                   '-------------------------------------------------------\n'  # a nota.
                                   'Escreva um número que seja maior ou igual a 0 e menor  \n'
                                   'ou igual a 10, por favor!!\n'
                                   '{}º nota: '.format(i))  # Esse format serve para indicar a nota que está
                    if float(nt) > 10 or float(nt) < 0:  # Após passar do while a cima ele vem para esse if que verifica
                        contador += 1  # se a variavel é > 10 e < 0, se for ele adiciona +1 no contador para mostrar o
                        limpartelar()  # erro. [ limpando a tela ]
                    else:
                        contador = 0  # Se a variavel for um número e entre 0 e 10 ele.
                        notas += str(nt) + ' '  # Adiciona o valor da nota numa string para no final ir para o arquivo.
                        n += float(nt)  # Soma todas as notas.
                        i += 1  # Adiciona 1 no contador e continua o loop com a nota que vem.
                        limpartelar()  # Limpando a tela.

                pted = input('-------------------------------------------------------\n'  # Variavel usada para
                             '|                Calculadora de médias                |\n'  # armazenar uma decisão.
                             '-------------------------------------------------------\n'
                             'Vai adicionar algum ponto?(s/n): ')
                if pted == 's' or pted == 'S':  # Se o valor da variavel de decisão anterior for s ou S.
                    while pted2 != 'm' or pted2 != 'n' or pted2 != 'M' or pted2 != 'N':  # Então ele entra nesse loop
                        limpartelar()  # que funciona até a variavel pted2 ser diferente de m ou M ou n ou N.
                        pted2 = input('-------------------------------------------------------\n'  # Variavel usada para
                                      '|                Calculadora de médias                |\n'  # armazenar uma
                                      '-------------------------------------------------------\n'  # decisão.
                                      'Na média ou na nota?(m = Média/n = Nota): ')
                        if pted2 == 'n' or pted == 'N':  # Se pted2 for n ou N ele pede a quantidade de pontos.
                            limpartelar()
                            pte = input('-------------------------------------------------------\n'  # Variavel usada
                                        '|                Calculadora de médias                |\n'  # para armazenar
                                        '-------------------------------------------------------\n'  # a quantidade de
                                        'Digite a quantidade de pontos: ')  # pontos.
                            try:  # Ele tentar converter esse valor pra int e ver se é menor que 0.
                                if int(pte) > 0:  # Se converter normal significa que é um número e que ele é postivo.
                                    limpartelar()  # Então ele sai da gambiarra. [ Limpando a tela ]
                                else:  # Se converter mais o valor não for maior que zero.
                                    pte = ';'  # adiciona um valor aleatorio um valor não numerico para entrar no loop.
                                    while not isfloat(pte):  # se o valor passado não for int ou float ele pede novamen-
                                        limpartelar()  # te até que seja float. [ Limpando a tela ]
                                        pte = input('-------------------------------------------------------\n'  # Vari-
                                                    '|                Calculadora de médias                |\n'  # avel
                                                    '-------------------------------------------------------\n'  # usa-
                                                    'Escreva um número e que seja maior que 0, ou igual!!\n'  # da para
                                                    'Digite a quantidade de pontos: ')  # armazenar a quantidade de pon-
                                        #                                                                           tos
                                        try:  # Ele tenta converter de novo, se converter e o valor for < 0 ele adiciona
                                            if int(pte) < 0:  # qualquer coisa na variavel para que não saia do loop.
                                                pte = ';'  # Se der erro ele sai normalmente ja que vai ser uma string e
                                        except ValueError:  # o loop vai rodar de novo. Ou seja a única condição se
                                            continue  # saida é se ela for númerica e postiva.
                            except ValueError:  # Se caso na conversão ocorrer um erro.
                                while not isfloat(pte):  # Se for um número inteiro ele passa normalmente.
                                    limpartelar()  # que seja float. [ Limpando a tela ]
                                    pte = input('-------------------------------------------------------\n'  # Variavel
                                                '|                Calculadora de médias                |\n'  # usada
                                                '-------------------------------------------------------\n'  # para
                                                'Escreva um número e que seja maior que 0, ou igual!!\n'  # armazenar
                                                'Digite a quantidade de pontos: ')  # a quantidade de pontos.
                                    try:  # Ele tenta converter de novo, se converter e o valor for < 0 ele adiciona
                                        if int(pte) < 0:  # qualquer coisa na variavel para que não saia do loop.
                                            pte = ';'  # Se der erro ele sai normalmente ja que vai ser uma string e o
                                    except ValueError:  # loop vai rodar de novo. Ou seja a única condição se saida é se
                                        continue  # ela for númerica e postiva.
                            n += float(pte)  # Convertendo o valor pra float e somando na nota
                            n /= int(numN)  # e encontrando a media dividindo a soma de todas as notas com o número de
                            break  # notas. E por ultimo quebra o loop, esse break foi de fundamental importancia.
                        # Algum bug fazia com que ele não saisse do loop ai eu botei isso ai.
                        elif pted2 == 'm' or pted2 == 'M':  # Se pted2 for m ou M ele pede a quantidade de pontos.
                            limpartelar()  # [ Limpando a tela ]
                            pte = input('-------------------------------------------------------\n'  # Variavel usada
                                        '|                Calculadora de médias                |\n'  # para armazenar
                                        '-------------------------------------------------------\n'  # a quantidade de
                                        'Digite a quantidade de pontos: ')  # pontos.
                            try:  # Ele tentar converter esse valor pra int e ver se é menor que 0.
                                if int(pte) > 0:  # Se converter normal significa que é um número e que ele é postivo.
                                    limpartelar()  # Então ele sai da gambiarra. [ Limpando a tela ]
                                else:  # Se converter mais o valor não for maior que zero.
                                    pte = ';'  # adiciona um valor aleatorio um valor não numerico para entrar no loop.
                                    while not isfloat(
                                            pte):  # se o valor passado não for int ou float ele pede novamente até
                                        limpartelar()  # que seja float. [ Limpando a tela ]
                                        pte = input(
                                            '-------------------------------------------------------\n'  # Variavel usa-
                                            '|                Calculadora de médias                |\n'  # da para arma-
                                            '-------------------------------------------------------\n'  # zenar a quan-
                                            'Escreva um número e que seja maior que 0, ou igual!!\n'  # tidade de pontos
                                            'Digite a quantidade de pontos: ')
                                        try:  # Ele tenta converter de novo, se converter e o valor for < 0 ele adiciona
                                            if int(pte) < 0:  # qualquer coisa na variavel para que não saia do loop.
                                                pte = ';'  # Se der erro ele sai normalmente ja que vai ser uma string e
                                        except ValueError:  # o loop vai rodar de novo. Ou seja a única condição se
                                            continue  # saida é se ela for númerica e postiva.
                            except ValueError:  # Se caso na conversão ocorrer um erro.
                                while not isfloat(pte):  # Se for um número inteiro ele passa normalmente.
                                    limpartelar()  # que seja float. [ Limpando a tela ]
                                    pte = input(
                                        '-------------------------------------------------------\n'  # Variavel usa-
                                        '|                Calculadora de médias                |\n'  # da para arma-
                                        '-------------------------------------------------------\n'  # zenar a quan-
                                        'Escreva um número e que seja maior que 0, ou igual!!\n'  # tidade de pontos.
                                        'Digite a quantidade de pontos: ')
                                    try:  # Ele tenta converter de novo, se converter e o valor for < 0 ele adiciona
                                        if int(pte) < 0:  # qualquer coisa na variavel para que não saia do loop.
                                            pte = ';'  # Se der erro ele sai normalmente ja que vai ser uma string e o
                                    except ValueError:  # loop vai rodar de novo. Ou seja a única condição se saida é se
                                        continue  # ela for númerica e postiva.

                            # -----------------------------------------------------------------------------------------
                            # Pensando aqui essa gambiarra acima poderia ser uma função ja que escrevi ela duas vezes,
                            # logo economizaria linhas. Se quiser fazer isso fica a seu criterio :D
                            # -----------------------------------------------------------------------------------------

                            n /= int(numN)  # Nesse caso como o ponto é na média ele faz a média primeiro e depois
                            n += float(pte)  # Soma os pontos ( ou o ponto ) na média.
                            break  # E o breakzinho para não evitar bugs.
                else:  # Se o usuario não querer adicionar ponto nenhum, ele calula a média normalmente,
                    n /= int(numN)  # com todas as notas somadas e o número se notas passado anteriormente.
                limpartelar()  # Limpando a tela
                nfd = input('-------------------------------------------------------\n'  # Variavel usada para armazenar
                            '|                Calculadora de médias                |\n'  # uma decisão.
                            '-------------------------------------------------------\n'
                            'Deseja adicionar o número de faltas?(s/n): ')
                if nfd == 's' or nfd == 'S':  # Se a variavel anterior for s ou S ele pede o número de faltas.
                    limpartelar()  # Limpando a Tela.
                    nf = input('-------------------------------------------------------\n'  # Variavel usada para arma-
                               '|                Calculadora de médias                |\n'  # zenar o número de faltas.
                               '-------------------------------------------------------\n'
                               'Escreva o número de faltas: ')
                    try:  # Ele tentar converter esse valor pra int e ver se é menor que 0.
                        if int(nf) > 0:  # Se converter normal significa que é um número e que ele é postivo.
                            limpartelar()  # Então ele sai da gambiarra. [ Limpando a tela ]
                        else:  # Se converter mais o valor não for maior que zero
                            nf = 'a'  # adiciona um valor aleatorio um valor não numerico para entrar no loop.
                            while not nf.isnumeric():  # Ele vai continuar aqui sempre que não for int.
                                limpartelar()  # Limpando a tela
                                nf = input('-------------------------------------------------------\n'  # Variavel usada
                                           '|                Calculadora de médias                |\n'  # para armazenar
                                           '-------------------------------------------------------\n'  # o número de
                                           'Escreva um número que seja positivo!!\n'  # de faltas.
                                           'Escreva o número de faltas: ')
                                try:  # Ele tenta converter de novo, se converter e o valor for < 0 ele adiciona um le-
                                    if int(nf) < 0:  # tra aleatoria na variavel para que não saia do loop.
                                        nf = ';'  # Se der erro ele sai normalmente ja que vai ser uma string e o loop
                                except ValueError:  # vai rodar de novo. Ou seja a única condição se saida é se ela for
                                    continue  # númerica e postiva.
                    except ValueError:  # Se caso na conversão ocorrer um erro.
                        while not nf.isnumeric():  # Se for um número inteiro ele passa normalmente.
                            limpartelar()  # Limpando a tela.
                            nf = input('-------------------------------------------------------\n'  # Variavel usada
                                       '|                Calculadora de médias                |\n'  # para armazenar
                                       '-------------------------------------------------------\n'  # o número de
                                       'Escreva um número que seja positivo!!\n'  # de faltas.
                                       'Escreva o número de faltas: ')
                            try:  # Ele tenta converter de novo, se converter e o valor for < 0 ele adiciona um le-
                                if int(nf) < 0:  # tra aleatoria na variavel para que não saia do loop.
                                    nf = ';'  # Se der erro ele sai normalmente ja que vai ser uma string e o loop
                            except ValueError:  # vai rodar de novo. Ou seja a única condição se saida é se ela for
                                continue  # númerica e postiva.
                else:  # Se o usuario não quiser adicionar faltas, por padrão já é zero.
                    pass
                limpartelar()  # Lipando a tela
                obsd = input('-------------------------------------------------------\n'  # Variavel usada para arma-
                             '|                Calculadora de médias                |\n'  # zenar o número de faltas.
                             '-------------------------------------------------------\n'
                             'Deseja escrever uma observação?(s/n): ')
                if obsd == 's' or obsd == 'S':  # Se for sim ele pede para escrever a observação.
                    obs = input('Escreva sua obsevação(max80): ')  # ela tem no maximo 80 caracteres por conta de or-
                    while len(obs) > 80:  # ganização no momento em que passa para o arquivo de texto.
                        obs = input('Escreva no maximo 80 caracteres: ')  # esse while é baseado no número de carac-
                # teres e roda até ser 80 ( É pouco mais fica organizado ).
                else:  # ( Só pra ter )
                    pass
                ltemp[1] = n  # Adicionamos a média na lista.
                if ltemp[1] > 10:  # Aí ajeitamos os valores. Caso seja maior que 10,
                    ltemp[1] = 10  # ele recebe 10.
                elif ltemp[1] < 0:  # Caso menor que 0,
                    ltemp[1] = 0  # ele recebe 0.
                else:  # ( Só pra ter mesmo )
                    pass
                arq = open(nmArq + '.txt', 'r')  # Abre o arquivo para leitura.
                ct = arq.readlines()  # Armazena numa variavel o seu conteudo.
                # "ct" vira uma lista então usamos o ".append" para adionar um novo item da lista no final dela.
                ct.append('Nome do aluno: {}\n'  # Então adicionamos nome do aluno, as notas, a média, as faltas e as
                          '{}\n'  # observações.
                          'Média: {}\n'
                          'Faltas: {}\n'
                          'Observações: {}\n'
                          '{}\n'
                          .format(ltemp[0], notas, ltemp[1], nf, obs[:28], obs[28:52]))

                # ----------------------------------------
                # Na minha concepção o fato do aluno ter recibido notas é necessario realça quanto e onde.
                # -----------------------------------------

                if pted2 == 'M' or pted2 == 'm':  # Nesse if se for "m" ( média ) ele pega os pontos faz uma mensagem e
                    ct.append('O aluno teve {} pontos adicionados à média\n'  # adiciona no ct.
                              '-----------------------------------------\n\n'.format(pte))
                elif pted2 == 'N' or pted2 == 'n':  # Nesse if se for "n" ( nota ) ele pega os pontos faz uma mensagem e
                    ct.append('O aluno teve {} pontos adicionados à nota\n'  # adiciona no ct.
                              '-----------------------------------------\n\n'.format(pte))
                else:  # Se nenhum ponto ter sido adicionado ele simplesmente fecha com "-".
                    ct.append('-----------------------------------------\n\n')
                arq.close()  # Fechando o arquivo de leitura.
                arq = open('{}.txt'.format(nmArq), 'w')  # Abrindo o arquivo para escrita.
                arq.writelines(ct)  # Escrevendo todas as listas do ct no arquivo.
                arq.close()  # Fechando o arquivo de escrita.
                # Tirando os valores das variaveis para não intervir em nada.
                notex = ''
                notas = 'Notas: '
                n = 0.0
                pted2 = ''

    elif dc1 == '2':  # Se no 1º menu o usuario escrever 2 ele fecha o arquivo normalmente.
        menu1 = False
    else:  # Caso ele não escreva 1 ou 2 ele limpa a tela e manda um alerta de erro.
        limpartelar()  # Limpando a Tela.
        print('Escreva uma opção correta')  # Mostrando mensagem de erro.
